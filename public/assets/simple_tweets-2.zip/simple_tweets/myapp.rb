require 'sinatra'

get '/' do
  erb :index
end
